#!/bin/bash
wget https://artifacts.elastic.co/downloads/logstash/logstash-8.4.1-x86_64.rpm
rpm -i logstash-8.4.1-x86_64.rpm
cp -r logstash/ /etc/logstash/
chmod -R +777 /etc/logstash/logstash/
cp elastic-agent-pipeline.conf /etc/logstash/conf.d
chmod +777 /etc/logstash/conf.d/elastic-agent-pipeline.conf
/usr/share/logstash/bin/logstash-plugin install logstash-input-beats
curl -L -O https://artifacts.elastic.co/downloads/beats/elastic-agent/elastic-agent-8.4.1-linux-x86_64.tar.gz
tar xzvf elastic-agent-8.4.1-linux-x86_64.tar.gz
cd elastic-agent-8.4.1-linux-x86_64
sudo ./elastic-agent install --fleet-server-es=https://mdr.cyarm.net:9200 --fleet-server-service-token=AAEAAWVsYXN0aWMvZmxlZXQtc2VydmVyL3Rva2VuLTE2NjI4Nzk3MDgyNjQ6MVpVOEszdmZUVW1rbVFWMFg2ekxMZw --fleet-server-policy=661c1170-319f-11ed-b004-cdbbad01d3bc

systemctl enable logstash
systemctl start logstash
systemctl enable elastic-agent
